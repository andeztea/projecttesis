<?php
defined('BASEPATH') or exit('No direct script access allowed');

class EmailController extends CI_Controller
{   

     public function index(){
        echo "asdasdasd";
     }

    public function sendmail()
    {
        $config = Array(
      'protocol' => 'smtp',
      'smtp_host' => 'samael.in-hell.com',
      'smtp_port' =>  465,
      'smtp_user' => 'info@andeznet.com', // change it to yours
      'smtp_pass' => 'sheilaon7', // change it to yours
      'mailtype' => 'html',
      'charset' => 'iso-8859-1',
      'wordwrap' => TRUE
    );

    $message = '';
            $this->load->library('email', $config);
          $this->email->set_newline("\r\n");
          $this->email->from('info@andeznet.com'); // change it to yours
          $this->email->to('andeztea@gmail.com');// change it to yours
          $this->email->subject('Resume from JobsBuddy for your Job posting');
          $this->email->message($message);
          if($this->email->send())
         {
          echo 'Email sent.';
         }
         else
        {
         show_error($this->email->print_debugger());
        }

    }


}