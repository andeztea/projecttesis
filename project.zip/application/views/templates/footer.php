<div id="myModal" class="modal myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content card-outline card-primary"></div>
    </div>
</div>

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        @Makrani 2022.
    </div>
    <!-- Default to the left -->
    <strong>Model Pembelajaran Entrepreneurship.</strong>
</footer>
</div>
<!-- ./wrapper -->